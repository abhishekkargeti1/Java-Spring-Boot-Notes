package com.FirstProjectSI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstProjectSiApplicationTests {

	@Test
	void contextLoads() {
	}

}
