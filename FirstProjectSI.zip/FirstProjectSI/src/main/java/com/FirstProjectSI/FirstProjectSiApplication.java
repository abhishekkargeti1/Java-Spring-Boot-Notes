package com.FirstProjectSI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstProjectSiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstProjectSiApplication.class, args);
	}

}
